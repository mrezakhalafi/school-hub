<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3">Class Details</h1>
                <div>
                    <a href="<?php echo e(route('classes.index')); ?>" class="btn btn-secondary">Back to List</a>
                    <a href="<?php echo e(route('classes.edit', $class)); ?>" class="btn btn-warning">Edit</a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Class Information</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th>Class Name:</th>
                            <td><?php echo e($class->name); ?></td>
                        </tr>
                        <tr>
                            <th>Level:</th>
                            <td><?php echo e($class->level); ?></td>
                        </tr>
                        <tr>
                            <th>Major:</th>
                            <td><?php echo e($class->major); ?></td>
                        </tr>
                        <tr>
                            <th>Section:</th>
                            <td><?php echo e($class->section ?: 'N/A'); ?></td>
                        </tr>
                        <tr>
                            <th>Class Advisor:</th>
                            <td>
                                <?php if($class->advisor): ?>
                                    <a href="<?php echo e(route('teachers.show', $class->advisor)); ?>" class="text-decoration-none">
                                        <?php echo e($class->advisor->first_name); ?> <?php echo e($class->advisor->last_name); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">Not assigned</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Description:</th>
                            <td><?php echo e($class->description ?: 'N/A'); ?></td>
                        </tr>
                        <tr>
                            <th>Student Count:</th>
                            <td><?php echo e($class->students->count()); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Students Section -->
            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Students in this Class</h5>
                    <a href="<?php echo e(route('students.create')); ?>?class_id=<?php echo e($class->id); ?>" class="btn btn-primary btn-sm">
                        Add Student
                    </a>
                </div>
                <div class="card-body">
                    <?php if($class->students->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Gender</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($student->student_id); ?></td>
                                            <td><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></td>
                                            <td><?php echo e(ucfirst($student->gender)); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('students.show', $student)); ?>" class="btn btn-sm btn-info">View</a>
                                                <a href="<?php echo e(route('students.edit', $student)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No students registered in this class.</p>
                        <a href="<?php echo e(route('students.create')); ?>?class_id=<?php echo e($class->id); ?>" class="btn btn-primary">
                            Add Student
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Delete Button -->
            <div class="mt-4">
                <form action="<?php echo e(route('classes.destroy', $class)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" 
                            onclick="return confirm('Are you sure you want to delete this class? All associated students will be affected.')">
                        Delete Class
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /media/mrezakhalafi/PERSONAL1/M Reza Khalafi (Secondary)/Qwen/school-hub/resources/views/classes/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3">Permission Reports</h1>
                <a href="<?php echo e(route('permission-reports.create')); ?>" class="btn btn-primary">Add New Permission Report</a>
            </div>

            <!-- Search and Filter Form -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('permission-reports.index')); ?>">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-3">
                                <label for="search" class="form-label">Search</label>
                                <input type="text" name="search" id="search" class="form-control" placeholder="Search by name or reason..." value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-2">
                                <label for="permission_type" class="form-label">Type</label>
                                <select name="permission_type" id="permission_type" class="form-select">
                                    <option value="">All Types</option>
                                    <?php $__currentLoopData = $permissionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($permissionType); ?>" <?php echo e(request('permission_type') == $permissionType ? 'selected' : ''); ?>>
                                            <?php echo e(ucfirst($permissionType)); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="status" class="form-label">Status</label>
                                <select name="status" id="status" class="form-select">
                                    <option value="">All Statuses</option>
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($statusOption); ?>" <?php echo e(request('status') == $statusOption ? 'selected' : ''); ?>>
                                            <?php echo e(ucfirst($statusOption)); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="class_id" class="form-label">Class</label>
                                <select name="class_id" id="class_id" class="form-select">
                                    <option value="">All Classes</option>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->id); ?>" <?php echo e(request('class_id') == $class->id ? 'selected' : ''); ?>>
                                            <?php echo e($class->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Filter</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Student Name</th>
                                    <th>Class</th>
                                    <th>Type</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Reason</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $permissionReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($report->student_name); ?></td>
                                        <td><?php echo e($report->student->class->name ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($report->permission_type === 'sick' ? 'danger' : ($report->permission_type === 'event' ? 'info' : ($report->permission_type === 'family' ? 'primary' : 'secondary'))); ?>">
                                                <?php echo e(ucfirst(__($report->permission_type))); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($report->permission_date)->format('M d, Y')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($report->permission_time)->format('H:i')); ?></td>
                                        <td><?php echo e(Str::limit($report->reason, 50)); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($report->status === 'approved' ? 'success' : ($report->status === 'rejected' ? 'danger' : 'warning')); ?>">
                                                <?php echo e(ucfirst($report->status)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($report->status === 'pending'): ?>
                                                <form method="POST" action="<?php echo e(route('permission-reports.status.update', $report)); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('POST'); ?>
                                                    <input type="hidden" name="status" value="approved">
                                                    <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to approve this permission?')">Approve</button>
                                                </form>
                                                <form method="POST" action="<?php echo e(route('permission-reports.status.update', $report)); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('POST'); ?>
                                                    <input type="hidden" name="status" value="rejected">
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to reject this permission?')">Reject</button>
                                                </form>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('permission-reports.show', $report)); ?>" class="btn btn-sm btn-info">View</a>
                                            <a href="<?php echo e(route('permission-reports.edit', $report)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <form action="<?php echo e(route('permission-reports.destroy', $report)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Are you sure you want to delete this permission report?')">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No permission reports found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-center">
                        <?php echo e($permissionReports->appends(['search' => request('search'), 'permission_type' => request('permission_type'), 'status' => request('status'), 'class_id' => request('class_id')])->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /media/mrezakhalafi/PERSONAL1/M Reza Khalafi (Secondary)/Qwen/school-hub/resources/views/permission-reports/index.blade.php ENDPATH**/ ?>
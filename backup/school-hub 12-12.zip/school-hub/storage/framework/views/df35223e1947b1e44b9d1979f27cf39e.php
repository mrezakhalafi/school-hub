<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3">Event Details</h1>
                <div>
                    <a href="<?php echo e(route('events.index')); ?>" class="btn btn-secondary">Back to List</a>
                    <a href="<?php echo e(route('events.edit', $event)); ?>" class="btn btn-warning">Edit</a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <?php if($event->image): ?>
                                <img src="<?php echo e(asset('storage/' . $event->image)); ?>" 
                                     alt="Event Image" class="img-fluid rounded">
                            <?php else: ?>
                                <div class="bg-light d-flex align-items-center justify-content-center" 
                                     style="height: 300px;">
                                    <i class="fas fa-calendar-alt text-muted" style="font-size: 5rem;"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="col-md-6">
                            <h2><?php echo e($event->title); ?></h2>
                            
                            <div class="mb-3">
                                <span class="badge bg-<?php echo e($event->event_type === 'academic' ? 'primary' : 
                                       ($event->event_type === 'sports' ? 'success' : 
                                       ($event->event_type === 'arts' ? 'info' : 
                                       ($event->event_type === 'extracurricular' ? 'warning' : 'secondary')))); ?> me-2">
                                    <?php echo e(ucfirst($event->event_type)); ?>

                                </span>
                                <span class="badge bg-<?php echo e($event->is_published ? 'success' : 'secondary'); ?>">
                                    <?php echo e($event->is_published ? 'Published' : 'Draft'); ?>

                                </span>
                            </div>
                            
                            <p class="text-muted"><i class="fas fa-calendar-alt me-2"></i> 
                                <?php echo e($event->start_date->format('M d, Y g:i A')); ?>

                                <?php if($event->end_date): ?>
                                    - <?php echo e($event->end_date->format('M d, Y g:i A')); ?>

                                <?php endif; ?>
                            </p>
                            
                            <?php if($event->location): ?>
                                <p class="text-muted"><i class="fas fa-map-marker-alt me-2"></i> <?php echo e($event->location); ?></p>
                            <?php endif; ?>
                            
                            <p><?php echo e($event->description ?: 'No description provided.'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Delete Button -->
            <div class="mt-4">
                <form action="<?php echo e(route('events.destroy', $event)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" 
                            onclick="return confirm('Are you sure you want to delete this event?')">
                        Delete Event
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /media/mrezakhalafi/PERSONAL1/M Reza Khalafi (Secondary)/Qwen/school-hub/resources/views/events/show.blade.php ENDPATH**/ ?>
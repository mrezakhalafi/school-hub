<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3">Classes</h1>
                <a href="<?php echo e(route('classes.create')); ?>" class="btn btn-primary">Add New Class</a>
            </div>
            
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Level</th>
                                    <th>Major</th>
                                    <th>Section</th>
                                    <th>Class Advisor</th>
                                    <th>Student Count</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr onclick="window.location='<?php echo e(route('classes.show', $class)); ?>'" style="cursor: pointer;">
                                        <td><?php echo e($class->name); ?></td>
                                        <td><?php echo e($class->level); ?></td>
                                        <td><?php echo e($class->major); ?></td>
                                        <td><?php echo e($class->section ?: 'N/A'); ?></td>
                                        <td>
                                            <?php if($class->advisor): ?>
                                                <a href="<?php echo e(route('teachers.show', $class->advisor)); ?>" class="text-decoration-none" onclick="event.stopPropagation();">
                                                    <?php echo e($class->advisor->first_name); ?> <?php echo e($class->advisor->last_name); ?>

                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted">Not assigned</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($class->students->count()); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('classes.edit', $class)); ?>" class="btn btn-sm btn-warning" onclick="event.stopPropagation();">Edit</a>
                                            <form action="<?php echo e(route('classes.destroy', $class)); ?>" method="POST" class="d-inline" onclick="event.stopPropagation();">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                        onclick="event.stopPropagation(); return confirm('Are you sure you want to delete this class? All associated students will be affected.')">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No classes found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-flex justify-content-center">
                        <?php echo e($classes->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /media/mrezakhalafi/PERSONAL1/M Reza Khalafi (Secondary)/Qwen/school-hub/resources/views/classes/index.blade.php ENDPATH**/ ?>